package com.yang.remote.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yang.remote.entity.Button;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface ButtonMapper extends BaseMapper<Button> {
    List<Button> list(Button button);
}
