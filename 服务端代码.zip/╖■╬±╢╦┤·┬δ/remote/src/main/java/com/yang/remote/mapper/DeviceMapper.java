package com.yang.remote.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yang.remote.dto.DeviceDto;
import com.yang.remote.entity.Device;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface DeviceMapper extends BaseMapper<Device> {
    Device selectByMqttId(Device device);

    List<DeviceDto> list(Device device);
}
