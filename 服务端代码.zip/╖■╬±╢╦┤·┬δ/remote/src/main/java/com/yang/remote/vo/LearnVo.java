package com.yang.remote.vo;

import lombok.Data;

import java.util.List;

@Data
public class LearnVo {
    Integer rawID;
    List<Integer> raw;
}
