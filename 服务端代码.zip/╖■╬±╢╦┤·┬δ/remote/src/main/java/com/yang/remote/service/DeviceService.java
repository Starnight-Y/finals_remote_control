package com.yang.remote.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.yang.remote.dto.DeviceDto;
import com.yang.remote.entity.Device;
import com.yang.remote.vo.HeartBeatVo;

import java.util.List;

public interface DeviceService extends IService<Device> {
    void heartBeat(HeartBeatVo heartBeatVo);

    Device add(Device device);

    boolean delete(Device device);

    Device update(Device device);

    List<DeviceDto> list(Device device);
}
