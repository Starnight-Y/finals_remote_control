package com.yang.remote.vo;

import lombok.Data;

@Data
public class UserVo {
    private String password;
    private String newPassword;
}
