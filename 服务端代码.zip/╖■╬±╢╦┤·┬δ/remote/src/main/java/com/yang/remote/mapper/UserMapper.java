package com.yang.remote.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yang.remote.entity.User;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface UserMapper extends BaseMapper<User> {
    User selectByUserName(User user);
}
