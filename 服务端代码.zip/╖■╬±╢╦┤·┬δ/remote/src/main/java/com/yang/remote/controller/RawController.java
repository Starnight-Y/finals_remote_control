package com.yang.remote.controller;

import com.yang.remote.service.RawService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/raw")
public class RawController {

    @Autowired
    RawService rawService;

}
