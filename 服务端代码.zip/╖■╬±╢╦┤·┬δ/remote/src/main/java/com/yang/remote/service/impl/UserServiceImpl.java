package com.yang.remote.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.yang.remote.common.base.ResultCodeEnum;
import com.yang.remote.common.exception.MyException;
import com.yang.remote.common.util.JwtInfo;
import com.yang.remote.common.util.JwtUtils;
import com.yang.remote.common.util.MyAssert;
import com.yang.remote.common.util.UserDetail;
import com.yang.remote.entity.User;
import com.yang.remote.mapper.UserMapper;
import com.yang.remote.service.UserService;
import com.yang.remote.vo.UserVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;

@Service
@Transactional
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {
    @Autowired
    UserMapper userMapper;

    @Override
    public String signIn(User user) {
        valid(user);
        User user1 = userMapper.selectByUserName(user);
        MyAssert.notNull(user1, ResultCodeEnum.LOGIN_USERNAME_OR_PASSWORD_ERROR);
        if ( !user1.getPassword().equals(user.getPassword()) ){
            throw new MyException(ResultCodeEnum.LOGIN_USERNAME_OR_PASSWORD_ERROR);
        }
        JwtInfo jwtInfo = new JwtInfo(user1.getId(), user1.getUserName());
        return JwtUtils.getJwtToken(jwtInfo, 60*60*24*30);
    }

    @Override
    public User signUp(User user) {
        valid(user);
        MyAssert.isNull(userMapper.selectByUserName(user), ResultCodeEnum.SIGN_UP_USERNAME_USED);
        if (userMapper.insert(user) != 1) {
            throw new MyException(ResultCodeEnum.SIGN_UP_ERROR);
        }
        return user;
    }

    @Override
    public User updatePassword(UserVo userVo) {
        MyAssert.notNull(userVo, ResultCodeEnum.PARAM_ERROR);
        MyAssert.notNull(userVo.getPassword(), ResultCodeEnum.PARAM_ERROR);
        MyAssert.notNull(userVo.getNewPassword(), ResultCodeEnum.PARAM_ERROR);

        User userDetail = UserDetail.getUserDetail();
        User user = userMapper.selectById(userDetail);
        if (!userDetail.getPassword().equals(user.getPassword())){
            throw new MyException(ResultCodeEnum.PASSWORD_ERROR);
        }
        user.setPassword(userVo.getNewPassword());
        user.setModifyTime(new Date());
        userMapper.updateById(user);
        return user;
    }

    @Override
    public void delete() {
        User userDetail = UserDetail.getUserDetail();
        userMapper.deleteById(userDetail);
    }

    @Override
    public String refresh() {
        User userDetail = UserDetail.getUserDetail();
        JwtInfo jwtInfo = new JwtInfo(userDetail.getId(), userDetail.getUserName());
        return JwtUtils.getJwtToken(jwtInfo, 60*60*24*30);
    }

    public void valid(User user){
        MyAssert.notNull(user, ResultCodeEnum.PARAM_ERROR);
        MyAssert.notNull(user.getUserName(), ResultCodeEnum.PARAM_ERROR);
        MyAssert.notNull(user.getPassword(), ResultCodeEnum.PARAM_ERROR);
    }
}
