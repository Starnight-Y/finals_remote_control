package com.yang.remote.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yang.remote.entity.Button;
import com.yang.remote.entity.Raw;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface RawMapper extends BaseMapper<Raw> {
    Raw selectByButtonId(Button button);
}
