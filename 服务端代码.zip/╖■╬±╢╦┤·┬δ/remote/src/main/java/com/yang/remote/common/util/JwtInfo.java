package com.yang.remote.common.util;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class JwtInfo {
    private Integer id;
    private String userName;
    //权限、角色等
    //不要存敏感信息
}
