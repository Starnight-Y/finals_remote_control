package com.yang.remote.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.yang.remote.entity.Button;

import java.util.List;

public interface ButtonService extends IService<Button> {
    void learn(Button button);

    void press(Button button);

    Button add(Button button);

    boolean delete(Button button);

    Button update(Button button);

    List<Button> list(Button button);
}
