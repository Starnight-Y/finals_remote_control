package com.yang.remote.controller;

import com.yang.remote.common.base.R;
import com.yang.remote.dto.DeviceDto;
import com.yang.remote.entity.Device;
import com.yang.remote.service.DeviceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/device")
public class DeviceController {

    @Autowired
    DeviceService deviceService;

    @PostMapping("/add")
    public R add(@RequestBody Device device){
        device = deviceService.add(device);
        return R.ok().data("device", device);
    }

    @DeleteMapping("/delete")
    public R delete(Device device){
        deviceService.delete(device);
        return R.ok();
    }

    @PostMapping("/update")
    public R update(@RequestBody Device device){
        device = deviceService.update(device);
        return R.ok().data("device", device);
    }

    @GetMapping("/list")
    public R list(Device device){
        List<DeviceDto> devices = deviceService.list(device);
        return R.ok().data("devices", devices);
    }
}
