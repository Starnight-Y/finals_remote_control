package com.yang.remote.vo;

import lombok.Data;

@Data
public class HeartBeatVo {
    private Integer id;
    private String mqttId;
}
