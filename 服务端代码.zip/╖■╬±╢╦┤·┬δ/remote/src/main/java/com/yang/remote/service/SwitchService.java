package com.yang.remote.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.yang.remote.entity.Switch;

public interface SwitchService extends IService<Switch> {
}
