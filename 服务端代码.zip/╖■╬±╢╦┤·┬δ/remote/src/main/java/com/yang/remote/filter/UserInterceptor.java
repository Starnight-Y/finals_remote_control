package com.yang.remote.filter;

import com.yang.remote.common.base.ResultCodeEnum;
import com.yang.remote.common.exception.MyException;
import com.yang.remote.common.util.JwtInfo;
import com.yang.remote.common.util.JwtUtils;
import com.yang.remote.common.util.UserDetail;
import com.yang.remote.entity.User;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class UserInterceptor implements HandlerInterceptor {
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
            throws Exception {
        String method = request.getMethod();
        if (method.equals("OPTIONS")){
            return true;
        }
        try {
            JwtInfo info = JwtUtils.getMemberIdByJwtToken(request);
            User user =new User();
            user.setUserName(info.getUserName());
            user.setId(info.getId());
            UserDetail.setUserDetail(user);
        }catch (Exception e){
            throw new MyException(ResultCodeEnum.LOGIN_AUTH);
        }
        return true;

    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        UserDetail.removeUserDetail();
    }
}
