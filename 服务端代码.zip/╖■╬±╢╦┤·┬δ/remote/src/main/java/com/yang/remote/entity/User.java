package com.yang.remote.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.*;

import java.io.Serializable;
import java.util.Date;
/*//无参构造
@NoArgsConstructor
//有参构造
@AllArgsConstructor
@Getter
@Setter
@EqualsAndHashCode*/
@EqualsAndHashCode(callSuper = false)
@Data
public class User implements Serializable {
    private static final long serialVersionUID=1L;

    /**
     * 用户id
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 用户名
     */
    private String userName;

    /**
     * 密码
     */
    private String password;

    /**
     * 创建时间
     */
    @TableField(value = "creat_time", fill = FieldFill.INSERT)
    private Date creatTime;

    /**
     * 修改时间
     */
    @TableField(value = "modify_time", fill = FieldFill.INSERT_UPDATE)
    private Date modifyTime;

    /**
     * 逻辑删除：0：未删除，1：已删除
     */
    private Boolean isDelete;


}
