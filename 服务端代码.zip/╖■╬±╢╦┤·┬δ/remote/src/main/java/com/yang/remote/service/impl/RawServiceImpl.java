package com.yang.remote.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.yang.remote.entity.Raw;
import com.yang.remote.mapper.RawMapper;
import com.yang.remote.service.RawService;
import com.yang.remote.vo.LearnVo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
@Slf4j
@Service
@Transactional
public class RawServiceImpl extends ServiceImpl<RawMapper, Raw> implements RawService {
    @Autowired
    RawMapper rawMapper;

    @Override
    public void deviceLearn(LearnVo learn) {
        if (learn == null || learn.getRawID() == null || learn.getRaw() == null || learn.getRaw().isEmpty()){
            return;
        }

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("raw", learn.getRaw());

        Raw raw = rawMapper.selectById(learn.getRawID());
        raw.setRawString(jsonObject.toJSONString());
        raw.setModifyTime(new Date());
        rawMapper.updateById(raw);
    }
}
