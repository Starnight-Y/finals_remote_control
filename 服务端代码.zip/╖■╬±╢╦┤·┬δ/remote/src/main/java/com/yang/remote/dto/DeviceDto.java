package com.yang.remote.dto;

import lombok.Data;

import java.util.Date;

@Data
public class DeviceDto {
    private Integer id;
    private String deviceName;
    private Date lastHeartbeatTime;
    private Boolean onLine;
}
