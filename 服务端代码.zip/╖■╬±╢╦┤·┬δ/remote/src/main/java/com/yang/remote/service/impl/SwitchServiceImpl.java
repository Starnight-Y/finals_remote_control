package com.yang.remote.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.yang.remote.entity.Switch;
import com.yang.remote.mapper.SwitchMapper;
import com.yang.remote.service.SwitchService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class SwitchServiceImpl extends ServiceImpl<SwitchMapper, Switch> implements SwitchService {
}
