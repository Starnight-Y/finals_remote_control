package com.yang.remote.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.yang.remote.entity.Raw;
import com.yang.remote.vo.LearnVo;

public interface RawService extends IService<Raw> {
    void deviceLearn(LearnVo learn);
}
