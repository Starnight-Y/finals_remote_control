class HttpOptions {

  //连接超时
  static const int CONNECT_TIMEOUT = 30000;

  //接收超时
  static const int RECEIVE_TIMEOUT = 30000;

  //base地址
  static const String BASE_URL = "http://101.132.69.83:8081/api";
  
}