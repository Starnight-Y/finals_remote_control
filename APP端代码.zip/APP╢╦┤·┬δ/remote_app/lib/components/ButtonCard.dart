import 'package:remote_app/models/Button.dart';
import 'package:remote_app/services/ButtonService.dart';
import 'package:flutter/material.dart';

class ButtonCard extends StatelessWidget {//在Flutter中，widget分为两类：Stateful（有状态）和 stateless（无状态）widget
  final Button button;

  const ButtonCard({Key key, this.button}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(15),
      child: Container(
        color: Colors.black38,
        width: double.infinity,
        height: 60,
        child: Center(
            child: Text(
          button.buttonName,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(color: Colors.white, fontSize: 20),
        )),
      ),
    );
  }
}
